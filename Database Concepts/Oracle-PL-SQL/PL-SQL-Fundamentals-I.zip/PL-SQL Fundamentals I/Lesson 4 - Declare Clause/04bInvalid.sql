--Set the server to output the results
SET SERVEROUTPUT ON;

DECLARE

	--Declare variables
	1Number	NUMBER(4);
	2Char	CHAR(10);
	
BEGIN
	--Tell the user that everything is working
	DBMS_OUTPUT.PUT_LINE('Compiled declarations successfully');
END;

